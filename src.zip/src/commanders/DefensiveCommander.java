package commanders;

import java.util.ArrayList;

import concepts.ActionProposal;
import concepts.PlacementProposal;
import bot.BotState;

public class DefensiveCommander extends TemplateCommander {

	@Override
	public ArrayList<PlacementProposal> getPlacementProposals(BotState state) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ActionProposal> getActionProposals(BotState state) {
		// TODO Auto-generated method stub
		return null;
	}


}
