package concepts;

public enum ActionType {
	ATTACK, MOVE; 
}
