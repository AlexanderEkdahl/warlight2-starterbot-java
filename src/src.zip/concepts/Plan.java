package concepts;

import map.SuperRegion;

public class Plan {
	SuperRegion sr;

}
