package commanders;

import java.util.ArrayList;

import bot.BotState;
import concepts.ActionProposal;
import concepts.PlacementProposal;

public class GriefCommander extends TemplateCommander {

	@Override
	public ArrayList<PlacementProposal> getPlacementProposals(BotState state) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<ActionProposal> getActionProposals(BotState state) {
		// TODO Auto-generated method stub
		return null;
	}

}
